#include <iostream>
#include <vector>
#include <algorithm>
#include <random>
#include <chrono>
using namespace std;
using namespace std::chrono;

void insertionSort(vector<int>& A) {
    int n = A.size();
    for (int i = 1; i < n; i++) {
        int key = A[i];
        int j = i - 1;
        while (j >= 0 && A[j] > key) {
            A[j + 1] = A[j];
            j--;
        }
        A[j + 1] = key;
    }
}

void printArray(const vector<int>& A) {
    for (int x : A) cout << x << " ";
    cout << endl;
}

int main() {
    random_device rd;
    mt19937 gen(rd());
    int n = 10000;

    //random num
    vector<int> pool(n);
    for (int i = 0; i < n; i++) pool[i] = i + 1;
    shuffle(pool.begin(), pool.end(), gen);
    vector<int> arr(pool.begin(), pool.begin() + n);

    cout << "Random Numbers (Without Duplicates)" << endl;
    cout << "Original Array:" << endl;
    printArray(arr);
    auto start = high_resolution_clock::now();
    insertionSort(arr);
    auto end = high_resolution_clock::now();
    cout << "\nSorted Array:" << endl;
    printArray(arr);
    cout << "\nExecution Time: " << duration<double>(end - start).count() << " seconds" << endl;

    //ASCENDING
    arr.clear();
    for (int i = 1; i <= n; i++) arr.push_back(i);
    cout << "\nAscending Order" << endl;
    cout << "Original Array of ascenging order:" << endl;
    printArray(arr);
    start = high_resolution_clock::now();
    insertionSort(arr);
    end = high_resolution_clock::now();
    cout << "Sorted Array:" << endl;
    printArray(arr);
    cout << "\nExecution Time: " << duration<double>(end - start).count() << " seconds" << endl;

    // Descending Order
    arr.clear();
    for (int i = n; i >= 1; i--) arr.push_back(i);
    cout << "\nDescending Order" << endl;
    cout << "Original Array:" << endl;
    printArray(arr);
    start = high_resolution_clock::now();
    insertionSort(arr);
    end = high_resolution_clock::now();
    cout << "Sorted Array:" << endl;
    printArray(arr);
    cout << "\nExecution Time: " << duration<double>(end - start).count() << " seconds" << endl;

    //  Missing Numbers
    int missingCount = max(1, n / 10);
    vector<int> full(n);
    for (int i = 0; i < n; i++) full[i] = i + 1;
    vector<int> shuffled = full;
    shuffle(shuffled.begin(), shuffled.end(), gen);
    vector<int> missing(shuffled.begin(), shuffled.begin() + missingCount);
    sort(missing.begin(), missing.end());
    arr = full;
    {
        vector<int> sortedMissing = missing;
        vector<int> filtered;
        filtered.reserve(arr.size());
        size_t mi = 0;
        for (int v : arr) {
            if (mi < sortedMissing.size() && v == sortedMissing[mi]) {
                mi++;
            } else {
                filtered.push_back(v);
            }
        }
        arr = filtered;
    }
    cout << "\nMissing Numbers" << endl;
    cout << "Missing Values:" << endl;
    printArray(missing);
    cout << "Original Array :" << endl;
    printArray(arr);
    start = high_resolution_clock::now();
    insertionSort(arr);
    end = high_resolution_clock::now();
    cout << "Sorted Array:" << endl;
    printArray(arr);
    cout << "\nExecution Time: " << duration<double>(end - start).count() << " seconds" << endl;

    //  Duplicate Numbers
    uniform_int_distribution<int> dist(1, n);
    arr.clear();
    for (int i = 0; i < n; i++) arr.push_back(dist(gen));
    cout << "\nDuplicate Numbers" << endl;
    cout << "Original Array:" << endl;
    printArray(arr);
    start = high_resolution_clock::now();
    insertionSort(arr);
    end = high_resolution_clock::now();
    cout << "Sorted Array:" << endl;
    printArray(arr);
    cout << "\nExecution Time: " << duration<double>(end - start).count() << " seconds" << endl;

    //partially ordered
    int half = n / 2;
    arr.clear();
    for (int i = 1; i <= half; i++) arr.push_back(i);
    for (int i = 0; i < n - half; i++) arr.push_back(dist(gen));
    cout << "\nPartially Ordered" << endl;
    cout << "Original Array:" << endl;
    printArray(arr);
    start = high_resolution_clock::now();
    insertionSort(arr);
    end = high_resolution_clock::now();
    cout << "Sorted Array:" << endl;
    printArray(arr);
    cout << "\nExecution Time: " << duration<double>(end - start).count() << " seconds" << endl;

    return 0;
}
