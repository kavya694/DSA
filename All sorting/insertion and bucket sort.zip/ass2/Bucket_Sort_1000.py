import random
import time

def bucket_sort(A):
    n = len(A)
    if n <= 1:
        return

    min_val = min(A)
    max_val = max(A)
    if min_val == max_val:
        return

    rng = max_val - min_val + 1
    buckets = [[] for _ in range(n)]

    for x in A:
        j = (x - min_val) * n // rng
        if j == n:
            j = n - 1
        buckets[j].append(x)

    for b in buckets:
        for p in range(1, len(b)):
            key = b[p]
            q = p - 1
            while q >= 0 and b[q] > key:
                b[q + 1] = b[q]
                q -= 1
            b[q + 1] = key

    idx = 0
    for b in buckets:
        for x in b:
            A[idx] = x
            idx += 1

#random num
n = 1000
arr = random.sample(range(1, n + 1), n)
print("Random Numbers (Without Duplicates)")
print("Original Array:")
print(arr)
start = time.perf_counter()
bucket_sort(arr)
end = time.perf_counter()
print("\nSorted Array:")
print(arr)
print(f"\nExecution Time: {end - start:.5f} seconds")
#ASCENDING
arr = list(range(1, n + 1))
print("\nAscending Order")
print("Original Array of ascenging order:")
print(arr)
start = time.perf_counter()
bucket_sort(arr)
end = time.perf_counter()
print("Sorted Array:")
print(arr)
print(f"\nExecution Time: {end - start:.5f} seconds")
# Descending Order 
arr = list(range(n, 0, -1))
print("\nDescending Order")
print("Original Array:")
print(arr)
start = time.perf_counter()
bucket_sort(arr)
end = time.perf_counter()
print("Sorted Array:")
print(arr)
print(f"\nExecution Time: {end - start:.5f} seconds")
#  Missing Numbers 
arr = list(range(1, n + 1))
missing_count = max(1, n // 10)
missing = random.sample(arr, missing_count)
for num in missing:
    arr.remove(num)
print("\nMissing Numbers")
print("Missing Values:")
print(sorted(missing))
print("Original Array :")
print(arr)
start = time.perf_counter()
bucket_sort(arr)
end = time.perf_counter()
print("Sorted Array:")
print(arr)
print(f"\nExecution Time: {end - start:.5f} seconds")
#  Duplicate Numbers 
arr = [random.randint(1, n) for _ in range(n)]
print("\nDuplicate Numbers")
print("Original Array:")
print(arr)
start = time.perf_counter()
bucket_sort(arr)
end = time.perf_counter()
print("Sorted Array:")
print(arr)
print(f"\nExecution Time: {end - start:.5f} seconds")
#partially ordered
half = n // 2
arr = []
for i in range(1, half + 1):
    arr.append(i)
for i in range(n - half):
    arr.append(random.randint(1, n))
print("\nPartially Ordered")
print("Original Array:")
print(arr)
start = time.perf_counter()
bucket_sort(arr)
end = time.perf_counter()
print("Sorted Array:")
print(arr)
print(f"\nExecution Time: {end - start:.5f} seconds")
