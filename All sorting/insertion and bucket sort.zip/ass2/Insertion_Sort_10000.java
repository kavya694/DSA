import java.util.*;

public class Insertion_Sort_10000 {

    public static void insertionSort(int[] A) {
        int n = A.length;
        for (int i = 1; i < n; i++) {
            int key = A[i];
            int j = i - 1;
            while (j >= 0 && A[j] > key) {
                A[j + 1] = A[j];
                j--;
            }
            A[j + 1] = key;
        }
    }

    public static void printArray(int[] A) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < A.length; i++) {
            sb.append(A[i]);
            if (i != A.length - 1) sb.append(", ");
        }
        sb.append("]");
        System.out.println(sb.toString());
    }

    public static void main(String[] args) {
        Random rand = new Random();
        int n = 10000;

        //random num
        List<Integer> pool = new ArrayList<>();
        for (int i = 1; i <= n; i++) pool.add(i);
        Collections.shuffle(pool, rand);
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) arr[i] = pool.get(i);

        System.out.println("Random Numbers (Without Duplicates)");
        System.out.println("Original Array:");
        printArray(arr);
        long start = System.nanoTime();
        insertionSort(arr);
        long end = System.nanoTime();
        System.out.println("\nSorted Array:");
        printArray(arr);
        System.out.printf("%nExecution Time: %.5f seconds%n", (end - start) / 1e9);

        //ASCENDING
        arr = new int[n];
        for (int i = 0; i < n; i++) arr[i] = i + 1;
        System.out.println("\nAscending Order");
        System.out.println("Original Array of ascenging order:");
        printArray(arr);
        start = System.nanoTime();
        insertionSort(arr);
        end = System.nanoTime();
        System.out.println("Sorted Array:");
        printArray(arr);
        System.out.printf("%nExecution Time: %.5f seconds%n", (end - start) / 1e9);

        // Descending Order
        arr = new int[n];
        for (int i = 0; i < n; i++) arr[i] = n - i;
        System.out.println("\nDescending Order");
        System.out.println("Original Array:");
        printArray(arr);
        start = System.nanoTime();
        insertionSort(arr);
        end = System.nanoTime();
        System.out.println("Sorted Array:");
        printArray(arr);
        System.out.printf("%nExecution Time: %.5f seconds%n", (end - start) / 1e9);

        //  Missing Numbers
        int missingCount = Math.max(1, n / 10);
        List<Integer> full = new ArrayList<>();
        for (int i = 1; i <= n; i++) full.add(i);
        List<Integer> shuffled = new ArrayList<>(full);
        Collections.shuffle(shuffled, rand);
        List<Integer> missing = new ArrayList<>(shuffled.subList(0, missingCount));
        Collections.sort(missing);
        List<Integer> remaining = new ArrayList<>(full);
        remaining.removeAll(missing);
        System.out.println("\nMissing Numbers");
        System.out.println("Missing Values:");
        printArray(missing.stream().mapToInt(Integer::intValue).toArray());
        System.out.println("Original Array :");
        int[] arrMissing = remaining.stream().mapToInt(Integer::intValue).toArray();
        printArray(arrMissing);
        start = System.nanoTime();
        insertionSort(arrMissing);
        end = System.nanoTime();
        System.out.println("Sorted Array:");
        printArray(arrMissing);
        System.out.printf("%nExecution Time: %.5f seconds%n", (end - start) / 1e9);

        //  Duplicate Numbers
        arr = new int[n];
        for (int i = 0; i < n; i++) arr[i] = rand.nextInt(n) + 1;
        System.out.println("\nDuplicate Numbers");
        System.out.println("Original Array:");
        printArray(arr);
        start = System.nanoTime();
        insertionSort(arr);
        end = System.nanoTime();
        System.out.println("Sorted Array:");
        printArray(arr);
        System.out.printf("%nExecution Time: %.5f seconds%n", (end - start) / 1e9);

        //partially ordered
        int half = n / 2;
        arr = new int[n];
        for (int i = 0; i < half; i++) arr[i] = i + 1;
        for (int i = 0; i < n - half; i++) arr[half + i] = rand.nextInt(n) + 1;
        System.out.println("\nPartially Ordered");
        System.out.println("Original Array:");
        printArray(arr);
        start = System.nanoTime();
        insertionSort(arr);
        end = System.nanoTime();
        System.out.println("Sorted Array:");
        printArray(arr);
        System.out.printf("%nExecution Time: %.5f seconds%n", (end - start) / 1e9);
    }
}
