import random
import time

def insertion_sort(A):
    n = len(A)
    for i in range(1, n):
        key = A[i]
        j = i - 1
        while j >= 0 and A[j] > key:
            A[j + 1] = A[j]
            j -= 1
        A[j + 1] = key

#random num
n = 1000
arr = random.sample(range(1, n + 1), n)
print("Random Numbers (Without Duplicates)")
print("Original Array:")
print(arr)
start = time.perf_counter()
insertion_sort(arr)
end = time.perf_counter()
print("\nSorted Array:")
print(arr)
print(f"\nExecution Time: {end - start:.5f} seconds")
#ASCENDING
arr = list(range(1, n + 1))
print("\nAscending Order")
print("Original Array of ascenging order:")
print(arr)
start = time.perf_counter()
insertion_sort(arr)
end = time.perf_counter()
print("Sorted Array:")
print(arr)
print(f"\nExecution Time: {end - start:.5f} seconds")
# Descending Order 
arr = list(range(n, 0, -1))
print("\nDescending Order")
print("Original Array:")
print(arr)
start = time.perf_counter()
insertion_sort(arr)
end = time.perf_counter()
print("Sorted Array:")
print(arr)
print(f"\nExecution Time: {end - start:.5f} seconds")
#  Missing Numbers 
arr = list(range(1, n + 1))
missing_count = max(1, n // 10)
missing = random.sample(arr, missing_count)
for num in missing:
    arr.remove(num)
print("\nMissing Numbers")
print("Missing Values:")
print(sorted(missing))
print("Original Array :")
print(arr)
start = time.perf_counter()
insertion_sort(arr)
end = time.perf_counter()
print("Sorted Array:")
print(arr)
print(f"\nExecution Time: {end - start:.5f} seconds")
#  Duplicate Numbers 
arr = [random.randint(1, n) for _ in range(n)]
print("\nDuplicate Numbers")
print("Original Array:")
print(arr)
start = time.perf_counter()
insertion_sort(arr)
end = time.perf_counter()
print("Sorted Array:")
print(arr)
print(f"\nExecution Time: {end - start:.5f} seconds")
#partially ordered
half = n // 2
arr = []
for i in range(1, half + 1):
    arr.append(i)
for i in range(n - half):
    arr.append(random.randint(1, n))
print("\nPartially Ordered")
print("Original Array:")
print(arr)
start = time.perf_counter()
insertion_sort(arr)
end = time.perf_counter()
print("Sorted Array:")
print(arr)
print(f"\nExecution Time: {end - start:.5f} seconds")
