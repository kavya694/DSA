import java.util.*;

public class heap1000 {

    // Heap Sort Algorithm
    static void heapSort(int[] arr) {
        int n = arr.length;

        // Build heap (rearrange array)
        for (int i = n / 2 - 1; i >= 0; i--) {
            heapify(arr, n, i);
        }

        // One by one extract an element from heap
        for (int i = n - 1; i > 0; i--) {
            // Move current root to end
            int temp = arr[0];
            arr[0] = arr[i];
            arr[i] = temp;

            // call max heapify on the reduced heap
            heapify(arr, i, 0);
        }
    }

    // To heapify a subtree rooted with node i which is an index in arr[]. n is size of heap
    static void heapify(int[] arr, int n, int i) {
        int largest = i; // Initialize largest as root
        int l = 2 * i + 1; // left = 2*i + 1
        int r = 2 * i + 2; // right = 2*i + 2

        // If left child is larger than root
        if (l < n && arr[l] > arr[largest])
            largest = l;

        // If right child is larger than largest so far
        if (r < n && arr[r] > arr[largest])
            largest = r;

        // If largest is not root
        if (largest != i) {
            int swap = arr[i];
            arr[i] = arr[largest];
            arr[largest] = swap;

            // Recursively heapify the affected sub-tree
            heapify(arr, n, largest);
        }
    }

    // Print Array
    static void printArray(int[] arr) {
        for (int x : arr)
            System.out.print(x + " ");
        System.out.println();
    }

    public static void main(String[] args) {

        int n = 1000; // Locked strictly to 1000
        Random rand = new Random();

        int[] arr;
        ArrayList<Integer> list = new ArrayList<>();
        ArrayList<Integer> missing = new ArrayList<>();

        // ================= Random Numbers (Without Duplicates) =================
        list.clear();
        for (int i = 1; i <= n; i++)
            list.add(i);

        Collections.shuffle(list);

        arr = new int[n];
        for (int i = 0; i < n; i++)
            arr[i] = list.get(i);

        System.out.println("==========================================");
        System.out.println("Random Numbers (Without Duplicates)");
        System.out.println("==========================================");
        System.out.println("Original Array:");
        printArray(arr);

        long start = System.nanoTime();
        heapSort(arr);
        long end = System.nanoTime();

        System.out.println("\nSorted Array:");
        printArray(arr);
        System.out.println("Execution Time: " + (end - start) + " ns");


        // ================= Ascending Order =================
        arr = new int[n];

        for (int i = 0; i < n; i++)
            arr[i] = i + 1;

        System.out.println("\n==========================================");
        System.out.println("Ascending Order");
        System.out.println("==========================================");
        System.out.println("Original Array:");
        printArray(arr);

        start = System.nanoTime();
        heapSort(arr);
        end = System.nanoTime();

        System.out.println("\nSorted Array:");
        printArray(arr);
        System.out.println("Execution Time: " + (end - start) + " ns");


        // ================= Descending Order =================
        arr = new int[n];

        for (int i = 0; i < n; i++)
            arr[i] = n - i;

        System.out.println("\n==========================================");
        System.out.println("Descending Order");
        System.out.println("==========================================");
        System.out.println("Original Array:");
        printArray(arr);

        start = System.nanoTime();
        heapSort(arr);
        end = System.nanoTime();

        System.out.println("\nSorted Array:");
        printArray(arr);
        System.out.println("Execution Time: " + (end - start) + " ns");


        // ================= Missing Numbers =================
        list.clear();
        for (int i = 1; i <= n; i++)
            list.add(i);

        Collections.shuffle(list);

        missing.clear();

        // Remove 100 numbers (10% of 1000)
        for (int i = 0; i < 100; i++) {
            missing.add(list.remove(0));
        }

        Collections.sort(missing);

        arr = new int[list.size()];
        for (int i = 0; i < list.size(); i++)
            arr[i] = list.get(i);

        System.out.println("\n==========================================");
        System.out.println("Missing Numbers");
        System.out.println("==========================================");

        System.out.println("Missing Values:");
        for (int x : missing)
            System.out.print(x + " ");

        System.out.println("\n\nOriginal Array:");
        printArray(arr);

        start = System.nanoTime();
        heapSort(arr);
        end = System.nanoTime();

        System.out.println("\nSorted Array:");
        printArray(arr);
        System.out.println("Execution Time: " + (end - start) + " ns");


        // ================= Duplicate Numbers =================
        arr = new int[n];

        for (int i = 0; i < n; i++)
            arr[i] = rand.nextInt(1000) + 1;

        System.out.println("\n==========================================");
        System.out.println("Duplicate Numbers");
        System.out.println("==========================================");
        System.out.println("Original Array:");
        printArray(arr);

        start = System.nanoTime();
        heapSort(arr);
        end = System.nanoTime();

        System.out.println("\nSorted Array:");
        printArray(arr);
        System.out.println("Execution Time: " + (end - start) + " ns");


        // ================= Partially Ordered =================
        arr = new int[n];

        // First half sorted
        for (int i = 0; i < n / 2; i++)
            arr[i] = i + 1;

        // Second half random
        for (int i = n / 2; i < n; i++)
            arr[i] = rand.nextInt(1000) + 1;

        System.out.println("\n==========================================");
        System.out.println("Partially Ordered");
        System.out.println("==========================================");
        System.out.println("Original Array:");
        printArray(arr);

        start = System.nanoTime();
        heapSort(arr);
        end = System.nanoTime();

        System.out.println("\nSorted Array:");
        printArray(arr);
        System.out.println("Execution Time: " + (end - start) + " ns");
    }
}