#bubble sort n=100,descending order numbers.
numbers = []
for i in range(100, 0, -1):
    numbers.append(i)

print("Before sorting:", numbers)

n = len(numbers)
for i in range(n):
    for j in range(0, n - i - 1):
        if numbers[j] > numbers[j + 1]:
            temp = numbers[j]
            numbers[j] = numbers[j + 1]
            numbers[j + 1] = temp

print("After sorting:", numbers)
#[Done] exited with code=0 in 0.122 seconds