#bubble sort n=1000,patrial order numbers.
import random

numbers = []
for i in range(1, 1001):
    numbers.append(i)

random.seed(42)
for k in range(5):
    idx1 = random.randint(0, 999)
    idx2 = random.randint(0, 999)

    temp = numbers[idx1]
    numbers[idx1] = numbers[idx2]
    numbers[idx2] = temp

print("Before sorting:", numbers)

n = len(numbers)
for i in range(n):
    for j in range(0, n - i - 1):
        if numbers[j] > numbers[j + 1]:
            temp = numbers[j]
            numbers[j] = numbers[j + 1]
            numbers[j + 1] = temp

print("After sorting:", numbers)
#[Done] exited with code=0 in 0.217 seconds