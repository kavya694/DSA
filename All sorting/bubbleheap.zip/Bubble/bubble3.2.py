#bubble sort n=10000,ascending order numbers.
numbers = []
for i in range(1, 10001):
    numbers.append(i)
print("Before sorting:", numbers)

n = len(numbers)
for i in range(n):
    for j in range(0, n - i - 1):
        if numbers[j] > numbers[j + 1]:
            temp = numbers[j]
            numbers[j] = numbers[j + 1]
            numbers[j + 1] = temp

print("After sorting:", numbers)
#[Done] exited with code=0 in 3.658 seconds