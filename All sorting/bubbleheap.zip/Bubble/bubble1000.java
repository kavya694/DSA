import java.util.*;

public class bubble1000 {

    // Bubble Sort Algorithm
    static void bubbleSort(int[] arr) {
        int n = arr.length;
        boolean swapped;
        for (int i = 0; i < n - 1; i++) {
            swapped = false;
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    // Swap arr[j] and arr[j+1]
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    swapped = true;
                }
            }
            // If no two elements were swapped by inner loop, then break
            if (!swapped)
                break;
        }
    }

    // Print Array
    static void printArray(int[] arr) {
        for (int x : arr)
            System.out.print(x + " ");
        System.out.println();
    }

    public static void main(String[] args) {

        int n = 1000; // Locked strictly to 1000
        Random rand = new Random();

        int[] arr;
        ArrayList<Integer> list = new ArrayList<>();
        ArrayList<Integer> missing = new ArrayList<>();

        // ================= Random Numbers (Without Duplicates) =================
        list.clear();
        for (int i = 1; i <= n; i++)
            list.add(i);

        Collections.shuffle(list);

        arr = new int[n];
        for (int i = 0; i < n; i++)
            arr[i] = list.get(i);

        System.out.println("==========================================");
        System.out.println("Random Numbers (Without Duplicates)");
        System.out.println("==========================================");
        System.out.println("Original Array:");
        printArray(arr);

        long start = System.nanoTime();
        bubbleSort(arr);
        long end = System.nanoTime();

        System.out.println("\nSorted Array:");
        printArray(arr);
        System.out.println("Execution Time: " + (end - start) + " ns");


        // ================= Ascending Order =================
        arr = new int[n];

        for (int i = 0; i < n; i++)
            arr[i] = i + 1;

        System.out.println("\n==========================================");
        System.out.println("Ascending Order");
        System.out.println("==========================================");
        System.out.println("Original Array:");
        printArray(arr);

        start = System.nanoTime();
        bubbleSort(arr);
        end = System.nanoTime();

        System.out.println("\nSorted Array:");
        printArray(arr);
        System.out.println("Execution Time: " + (end - start) + " ns");


        // ================= Descending Order =================
        arr = new int[n];

        for (int i = 0; i < n; i++)
            arr[i] = n - i;

        System.out.println("\n==========================================");
        System.out.println("Descending Order");
        System.out.println("==========================================");
        System.out.println("Original Array:");
        printArray(arr);

        start = System.nanoTime();
        bubbleSort(arr);
        end = System.nanoTime();

        System.out.println("\nSorted Array:");
        printArray(arr);
        System.out.println("Execution Time: " + (end - start) + " ns");


        // ================= Missing Numbers =================
        list.clear();
        for (int i = 1; i <= n; i++)
            list.add(i);

        Collections.shuffle(list);

        missing.clear();

        // Remove 100 numbers (Matches the original design constraint)
        for (int i = 0; i < 100; i++) {
            missing.add(list.remove(0));
        }

        Collections.sort(missing);

        arr = new int[list.size()];
        for (int i = 0; i < list.size(); i++)
            arr[i] = list.get(i);

        System.out.println("\n==========================================");
        System.out.println("Missing Numbers");
        System.out.println("==========================================");

        System.out.println("Missing Values:");
        for (int x : missing)
            System.out.print(x + " ");

        System.out.println("\n\nOriginal Array:");
        printArray(arr);

        start = System.nanoTime();
        bubbleSort(arr);
        end = System.nanoTime();

        System.out.println("\nSorted Array:");
        printArray(arr);
        System.out.println("Execution Time: " + (end - start) + " ns");


        // ================= Duplicate Numbers =================
        arr = new int[n];

        for (int i = 0; i < n; i++)
            arr[i] = rand.nextInt(1000) + 1;

        System.out.println("\n==========================================");
        System.out.println("Duplicate Numbers");
        System.out.println("==========================================");
        System.out.println("Original Array:");
        printArray(arr);

        start = System.nanoTime();
        bubbleSort(arr);
        end = System.nanoTime();

        System.out.println("\nSorted Array:");
        printArray(arr);
        System.out.println("Execution Time: " + (end - start) + " ns");


        // ================= Partially Ordered =================
        arr = new int[n];

        // First half sorted
        for (int i = 0; i < n / 2; i++)
            arr[i] = i + 1;

        // Second half random
        for (int i = n / 2; i < n; i++)
            arr[i] = rand.nextInt(1000) + 1;

        System.out.println("\n==========================================");
        System.out.println("Partially Ordered");
        System.out.println("==========================================");
        System.out.println("Original Array:");
        printArray(arr);

        start = System.nanoTime();
        bubbleSort(arr);
        end = System.nanoTime();

        System.out.println("\nSorted Array:");
        printArray(arr);
        System.out.println("Execution Time: " + (end - start) + " ns");
    }
}
