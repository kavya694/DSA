#bubble sort n=100000,duplicate numbers.
import random

numbers = []
current_number = 1
while len(numbers) < 100000:
    if random.random() < 0.7:
        numbers.append(current_number)
    current_number += 1

print("Before sorting:", numbers)

n = len(numbers)
for i in range(n):
    for j in range(0, n - i - 1):
        if numbers[j] > numbers[j + 1]:
            temp = numbers[j]
            numbers[j] = numbers[j + 1]
            numbers[j + 1] = temp

print("After sorting:", numbers)