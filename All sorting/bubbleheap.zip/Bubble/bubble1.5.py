#bubble sort n=100,duplicate numbers.
import random

numbers = []
current_number = 1
while len(numbers) < 100:
    if random.random() < 0.7:
        numbers.append(current_number)
    current_number += 1

print("Before sorting:", numbers)

n = len(numbers)
for i in range(n):
    for j in range(0, n - i - 1):
        if numbers[j] > numbers[j + 1]:
            temp = numbers[j]
            numbers[j] = numbers[j + 1]
            numbers[j + 1] = temp

print("After sorting:", numbers)

#[Done] exited with code=0 in 0.115 seconds