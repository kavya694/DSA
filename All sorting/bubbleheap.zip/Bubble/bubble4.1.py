#bubble sort n=100000,random numbers.
import random

numbers = []
for i in range(100000):
    numbers.append(random.randint(1, 500000))
print("Before sorting:", numbers)
n = len(numbers)
for i in range(n):
    for j in range(0, n - i - 1):
        if numbers[j] > numbers[j + 1]:
            temp = numbers[j]
            numbers[j] = numbers[j + 1]
            numbers[j + 1] = temp

print("After sorting:", numbers)