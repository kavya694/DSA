#bubble sort n=100,random numbers.
import random

numbers = []
for i in range(100):
    numbers.append(random.randint(1, 1000))
print("Before sorting:", numbers)
n = len(numbers)
for i in range(n):
    for j in range(0, n - i - 1):
        if numbers[j] > numbers[j + 1]:
            temp = numbers[j]
            numbers[j] = numbers[j + 1]
            numbers[j + 1] = temp

print("After sorting:", numbers)
#[Done] exited with code=0 in 0.145 seconds