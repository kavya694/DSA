#include <iostream>
#include <vector>
#include <random>
#include <algorithm>
#include <chrono>

using namespace std;

// Bubble sort
void bubbleSort(vector<int>& arr) {
    int n = arr.size();
    bool swapped;
    for (int i = 0; i < n - 1; i++) {
        swapped = false;
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
                swapped = true;
            }
        }
        if (!swapped)
            break;
    }
}

// Display array
void printArray(const vector<int>& arr) {
    for (int x : arr) {
        cout << x << " ";
    }
    cout << "\n";
}

int main() {
    int n = 100000;
    
    // Random engine
    random_device rd;
    mt19937 g(rd());
    
    vector<int> arr;
    vector<int> list;
    vector<int> missing;

    // Case 1
    list.clear();
    for (int i = 1; i <= n; i++)
        list.push_back(i);

    shuffle(list.begin(), list.end(), g);
    arr = list;

    cout << "==========================================" << "\n";
    cout << "Random Numbers (Without Duplicates)" << "\n";
    cout << "==========================================" << "\n";
    cout << "Original Array:" << "\n";
    printArray(arr);

    // Benchmarking
    auto start = chrono::high_resolution_clock::now();
    bubbleSort(arr);
    auto end = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::nanoseconds>(end - start).count();

    cout << "\nSorted Array:" << "\n";
    printArray(arr);
    cout << "Execution Time: " << duration << " ns" << "\n";

    // Case 2
    arr.resize(n);
    for (int i = 0; i < n; i++)
        arr[i] = i + 1;

    cout << "\n==========================================" << "\n";
    cout << "Ascending Order" << "\n";
    cout << "==========================================" << "\n";
    cout << "Original Array:" << "\n";
    printArray(arr);

    // Benchmarking
    start = chrono::high_resolution_clock::now();
    bubbleSort(arr);
    end = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::nanoseconds>(end - start).count();

    cout << "\nSorted Array:" << "\n";
    printArray(arr);
    cout << "Execution Time: " << duration << " ns" << "\n";

    // Case 3
    arr.resize(n);
    for (int i = 0; i < n; i++)
        arr[i] = n - i;

    cout << "\n==========================================" << "\n";
    cout << "Descending Order" << "\n";
    cout << "==========================================" << "\n";
    cout << "Original Array:" << "\n";
    printArray(arr);

    // Benchmarking
    start = chrono::high_resolution_clock::now();
    bubbleSort(arr);
    end = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::nanoseconds>(end - start).count();

    cout << "\nSorted Array:" << "\n";
    printArray(arr);
    cout << "Execution Time: " << duration << " ns" << "\n";

    // Case 4
    list.clear();
    for (int i = 1; i <= n; i++)
        list.push_back(i);

    shuffle(list.begin(), list.end(), g);
    missing.clear();

    // Remove elements
    for (int i = 0; i < 10000; i++) {
        missing.push_back(list[0]);
        list.erase(list.begin());
    }

    sort(missing.begin(), missing.end());
    arr = list;

    cout << "\n==========================================" << "\n";
    cout << "Missing Numbers" << "\n";
    cout << "==========================================" << "\n";
    cout << "Missing Values:" << "\n";
    for (int x : missing)
        cout << x << " ";
    cout << "\n\nOriginal Array:" << "\n";
    printArray(arr);

    // Benchmarking
    start = chrono::high_resolution_clock::now();
    bubbleSort(arr);
    end = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::nanoseconds>(end - start).count();

    cout << "\nSorted Array:" << "\n";
    printArray(arr);
    cout << "Execution Time: " << duration << " ns" << "\n";

    // Case 5
    arr.resize(n);
    uniform_int_distribution<int> dist(1, 100000);
    for (int i = 0; i < n; i++)
        arr[i] = dist(g);

    cout << "\n==========================================" << "\n";
    cout << "Duplicate Numbers" << "\n";
    cout << "==========================================" << "\n";
    cout << "Original Array:" << "\n";
    printArray(arr);

    // Benchmarking
    start = chrono::high_resolution_clock::now();
    bubbleSort(arr);
    end = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::nanoseconds>(end - start).count();

    cout << "\nSorted Array:" << "\n";
    printArray(arr);
    cout << "Execution Time: " << duration << " ns" << "\n";

    // Case 6
    arr.resize(n);
    for (int i = 0; i < n / 2; i++)
        arr[i] = i + 1;

    for (int i = n / 2; i < n; i++)
        arr[i] = dist(g);

    cout << "\n==========================================" << "\n";
    cout << "Partially Ordered" << "\n";
    cout << "==========================================" << "\n";
    cout << "Original Array:" << "\n";
    printArray(arr);

    // Benchmarking
    start = chrono::high_resolution_clock::now();
    bubbleSort(arr);
    end = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::nanoseconds>(end - start).count();

    cout << "\nSorted Array:" << "\n";
    printArray(arr);
    cout << "Execution Time: " << duration << " ns" << "\n";

    return 0;
}