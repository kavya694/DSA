#bubble sort n=10000,random numbers.
import random

numbers = []
for i in range(10000):
    numbers.append(random.randint(1, 50000))
print("Before sorting:", numbers)
n = len(numbers)
for i in range(n):
    for j in range(0, n - i - 1):
        if numbers[j] > numbers[j + 1]:
            temp = numbers[j]
            numbers[j] = numbers[j + 1]
            numbers[j + 1] = temp

print("After sorting:", numbers)
#[Done] exited with code=0 in 6.928 seconds