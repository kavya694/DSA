#include <iostream>
#include <vector>
#include <algorithm>
#include <random>
#include <chrono>

using namespace std;
using namespace std::chrono;

// Selection Sort Function
void selectionSort(vector<int>& arr) {
    int n = arr.size();

    for (int i = 0; i < n - 1; i++) {
        int minIndex = i;

        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[minIndex]) {
                minIndex = j;
            }
        }

        swap(arr[i], arr[minIndex]);
    }
}

int main() {

    int n = 100;
    random_device rd;
    mt19937 gen(rd());

    vector<int> arr;
    vector<int> list;
    vector<int> missing;

    // ================= Random Numbers (Without Duplicates) =================
    list.clear();
    for (int i = 1; i <= 100; i++) {
        list.push_back(i);
    }

    shuffle(list.begin(), list.end(), gen);

    arr = list;

    cout << "Random Numbers (Without Duplicates)\n";
    cout << "Original Array:\n";
    for (int x : arr)
        cout << x << " ";

    auto start = high_resolution_clock::now();
    selectionSort(arr);
    auto end = high_resolution_clock::now();

    cout << "\n\nSorted Array:\n";
    for (int x : arr)
        cout << x << " ";

    cout << "\nExecution Time: "
         << duration_cast<nanoseconds>(end - start).count()
         << " ns\n";



    // ================= Ascending Order =================
    arr.clear();

    for (int i = 1; i <= n; i++) {
        arr.push_back(i);
    }

    cout << "\n\nAscending Order\n";
    cout << "Original Array:\n";
    for (int x : arr)
        cout << x << " ";

    start = high_resolution_clock::now();
    selectionSort(arr);
    end = high_resolution_clock::now();

    cout << "\nSorted Array:\n";
    for (int x : arr)
        cout << x << " ";

    cout << "\nExecution Time: "
         << duration_cast<nanoseconds>(end - start).count()
         << " ns\n";



    // ================= Descending Order =================
    arr.clear();

    for (int i = n; i >= 1; i--) {
        arr.push_back(i);
    }

    cout << "\n\nDescending Order\n";
    cout << "Original Array:\n";
    for (int x : arr)
        cout << x << " ";

    start = high_resolution_clock::now();
    selectionSort(arr);
    end = high_resolution_clock::now();

    cout << "\nSorted Array:\n";
    for (int x : arr)
        cout << x << " ";

    cout << "\nExecution Time: "
         << duration_cast<nanoseconds>(end - start).count()
         << " ns\n";



    // ================= Missing Numbers =================
    list.clear();

    for (int i = 1; i <= 100; i++) {
        list.push_back(i);
    }

    shuffle(list.begin(), list.end(), gen);

    missing.clear();

    for (int i = 0; i < 10; i++) {
        missing.push_back(list.front());
        list.erase(list.begin());
    }

    sort(missing.begin(), missing.end());

    arr = list;

    cout << "\n\nMissing Numbers\n";
    cout << "Missing Values:\n";
    for (int x : missing)
        cout << x << " ";

    cout << "\nOriginal Array:\n";
    for (int x : arr)
        cout << x << " ";

    start = high_resolution_clock::now();
    selectionSort(arr);
    end = high_resolution_clock::now();

    cout << "\nSorted Array:\n";
    for (int x : arr)
        cout << x << " ";

    cout << "\nExecution Time: "
         << duration_cast<nanoseconds>(end - start).count()
         << " ns\n";



    // ================= Duplicate Numbers =================
    arr.clear();

    uniform_int_distribution<> dist(1, 100);

    for (int i = 0; i < n; i++) {
        arr.push_back(dist(gen));
    }

    cout << "\n\nDuplicate Numbers\n";
    cout << "Original Array:\n";
    for (int x : arr)
        cout << x << " ";

    start = high_resolution_clock::now();
    selectionSort(arr);
    end = high_resolution_clock::now();

    cout << "\nSorted Array:\n";
    for (int x : arr)
        cout << x << " ";

    cout << "\nExecution Time: "
         << duration_cast<nanoseconds>(end - start).count()
         << " ns\n";



    // ================= Partially Ordered =================
    arr.clear();

    // First 50 elements sorted
    for (int i = 1; i <= 50; i++) {
        arr.push_back(i);
    }

    // Remaining 50 elements random
    for (int i = 51; i <= 100; i++) {
        arr.push_back(dist(gen));
    }

    cout << "\n\nPartially Ordered\n";
    cout << "Original Array:\n";
    for (int x : arr)
        cout << x << " ";

    start = high_resolution_clock::now();
    selectionSort(arr);
    end = high_resolution_clock::now();

    cout << "\nSorted Array:\n";
    for (int x : arr)
        cout << x << " ";

    cout << "\nExecution Time: "
         << duration_cast<nanoseconds>(end - start).count()
         << " ns\n";

    return 0;
}