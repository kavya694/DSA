#include <iostream>
#include <vector>
#include <algorithm>
#include <random>
#include <chrono>

using namespace std;
using namespace std::chrono;

void selectionSort(vector<int>& arr)
{
    int n = arr.size();

    for (int i = 0; i < n - 1; i++)
    {
        int minIndex = i;

        for (int j = i + 1; j < n; j++)
        {
            if (arr[j] < arr[minIndex])
                minIndex = j;
        }

        swap(arr[i], arr[minIndex]);
    }
}

int main()
{
    int n = 100000;

    random_device rd;
    mt19937 gen(rd());

    vector<int> arr;
    vector<int> list;
    vector<int> missing;

    // ================= Random Numbers =================

    list.clear();

    for (int i = 1; i <= n; i++)
        list.push_back(i);

    shuffle(list.begin(), list.end(), gen);

    arr = list;

    cout << "Random Numbers\n";

    auto start = high_resolution_clock::now();
    selectionSort(arr);
    auto end = high_resolution_clock::now();

    cout << "Execution Time: "
         << duration_cast<milliseconds>(end - start).count()
         << " ms\n";

    // ================= Ascending =================

    arr.clear();

    for (int i = 1; i <= n; i++)
        arr.push_back(i);

    cout << "\nAscending Order\n";

    start = high_resolution_clock::now();
    selectionSort(arr);
    end = high_resolution_clock::now();

    cout << "Execution Time: "
         << duration_cast<milliseconds>(end - start).count()
         << " ms\n";

    // ================= Descending =================

    arr.clear();

    for (int i = n; i >= 1; i--)
        arr.push_back(i);

    cout << "\nDescending Order\n";

    start = high_resolution_clock::now();
    selectionSort(arr);
    end = high_resolution_clock::now();

    cout << "Execution Time: "
         << duration_cast<milliseconds>(end - start).count()
         << " ms\n";

    // ================= Missing Numbers =================

    list.clear();

    for (int i = 1; i <= n; i++)
        list.push_back(i);

    shuffle(list.begin(), list.end(), gen);

    missing.assign(list.begin(), list.begin() + 10);
    list.erase(list.begin(), list.begin() + 10);

    arr = list;

    cout << "\nMissing Numbers\n";

    start = high_resolution_clock::now();
    selectionSort(arr);
    end = high_resolution_clock::now();

    cout << "Execution Time: "
         << duration_cast<milliseconds>(end - start).count()
         << " ms\n";

    // ================= Duplicate Numbers =================

    arr.clear();

    uniform_int_distribution<> dist(1, 100);

    for (int i = 0; i < n; i++)
        arr.push_back(dist(gen));

    cout << "\nDuplicate Numbers\n";

    start = high_resolution_clock::now();
    selectionSort(arr);
    end = high_resolution_clock::now();

    cout << "Execution Time: "
         << duration_cast<milliseconds>(end - start).count()
         << " ms\n";

    // ================= Partially Ordered =================

    arr.clear();

    for (int i = 1; i <= n / 2; i++)
        arr.push_back(i);

    for (int i = n / 2 + 1; i <= n; i++)
        arr.push_back(dist(gen));

    cout << "\nPartially Ordered\n";

    start = high_resolution_clock::now();
    selectionSort(arr);
    end = high_resolution_clock::now();

    cout << "Execution Time: "
         << duration_cast<milliseconds>(end - start).count()
         << " ms\n";

    return 0;
}