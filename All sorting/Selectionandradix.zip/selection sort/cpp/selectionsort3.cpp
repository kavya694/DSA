#include <iostream>
#include <vector>
#include <algorithm>
#include <random>
#include <chrono>

using namespace std;
using namespace chrono;


void selectionSort(vector<int>& arr) {
    int n = arr.size();

    for (int i = 0; i < n - 1; i++) {
        int minIndex = i;

        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[minIndex]) {
                minIndex = j;
            }
        }

        swap(arr[i], arr[minIndex]);
    }
}

int main() {

    int n = 10000;

    random_device rd;
    mt19937 gen(rd());

    vector<int> arr;
    vector<int> list;
    vector<int> missing;

    //  Random Numbers 
    for (int i = 1; i <= n; i++)
        list.push_back(i);

    shuffle(list.begin(), list.end(), gen);
    arr = list;

    cout << "========== Random Numbers (Without Duplicates) ==========\n";

    auto start = high_resolution_clock::now();
    selectionSort(arr);
    auto end = high_resolution_clock::now();

    cout << "First 200 Sorted Elements:\n";
    for (int i = 0; i < 200; i++)
        cout << arr[i] << " ";

    cout << "\nExecution Time: "
         << duration_cast<microseconds>(end - start).count()
         << " microseconds\n\n";


    // Ascending Order 
    arr.clear();

    for (int i = 1; i <= n; i++)
        arr.push_back(i);

    cout << "========== Ascending Order ==========\n";

    start = high_resolution_clock::now();
    selectionSort(arr);
    end = high_resolution_clock::now();

    cout << "First 200 Sorted Elements:\n";
    for (int i = 0; i < 200; i++)
        cout << arr[i] << " ";

    cout << "\nExecution Time: "
         << duration_cast<microseconds>(end - start).count()
         << " microseconds\n\n";


    //  Descending Order 
    arr.clear();

    for (int i = n; i >= 1; i--)
        arr.push_back(i);

    cout << "========== Descending Order ==========\n";

    start = high_resolution_clock::now();
    selectionSort(arr);
    end = high_resolution_clock::now();

    cout << "First 200 Sorted Elements:\n";
    for (int i = 0; i < 200; i++)
        cout << arr[i] << " ";

    cout << "\nExecution Time: "
         << duration_cast<microseconds>(end - start).count()
         << " microseconds\n\n";


    //  Missing Numbers 
    list.clear();

    for (int i = 1; i <= n; i++)
        list.push_back(i);

    shuffle(list.begin(), list.end(), gen);

    missing.clear();

   
    for (int i = 0; i < 1000; i++) {
        missing.push_back(list.front());
        list.erase(list.begin());
    }

    sort(missing.begin(), missing.end());

    arr = list;

    cout << "= Missing Numbers ===\n";

    start = high_resolution_clock::now();
    selectionSort(arr);
    end = high_resolution_clock::now();

    cout << "Missing Values:\n";
    for (int x : missing)
        cout << x << " ";

    cout << "\nFirst 2000 Sorted Elements:\n";
    for (int i = 0; i < 2000; i++)
        cout << arr[i] << " ";

    cout << "\nExecution Time: "
         << duration_cast<microseconds>(end - start).count()
         << " microseconds\n\n";


    //  Duplicate Numbers 
    arr.clear();

    uniform_int_distribution<> dist(1, n);

    for (int i = 0; i < n; i++)
        arr.push_back(dist(gen));

    cout << "========== Duplicate Numbers ==========\n";

    start = high_resolution_clock::now();
    selectionSort(arr);
    end = high_resolution_clock::now();

    cout << "First 200 Sorted Elements:\n";
    for (int i = 0; i < 200; i++)
        cout << arr[i] << " ";

    cout << "\nExecution Time: "
         << duration_cast<microseconds>(end - start).count()
         << " microseconds\n\n";


    //  Partially Ordered
    arr.clear();

    for (int i = 1; i <= 5000; i++)
        arr.push_back(i);

    for (int i = 5001; i <= n; i++)
        arr.push_back(dist(gen));

    cout << "========== Partially Ordered ==========\n";

    start = high_resolution_clock::now();
    selectionSort(arr);
    end = high_resolution_clock::now();

    cout << "First 2000 Sorted Elements:\n";
    for (int i = 0; i < 2000; i++)
        cout << arr[i] << " ";

    cout << "\nExecution Time: "
         << duration_cast<microseconds>(end - start).count()
         << " microseconds\n";

    return 0;
}