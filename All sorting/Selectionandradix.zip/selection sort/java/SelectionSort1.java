import java.util.*;

public class SelectionSort1 {

    
    static void selectionSort(int[] arr) {
        int n = arr.length;

        for (int i = 0; i < n - 1; i++) {
            int min = i;

            for (int j = i + 1; j < n; j++) {
                if (arr[j] < arr[min]) {
                    min = j;
                }
            }

            int temp = arr[i];
            arr[i] = arr[min];
            arr[min] = temp;
        }
    }

    public static void main(String[] args) {

        Random random = new Random();
        int n = 100;

        // Random Numbers (Without Duplicates) 
        ArrayList<Integer> list = new ArrayList<>();

        for (int i = 1; i <= 100; i++) {
            list.add(i);
        }

        Collections.shuffle(list);

        int[] arr = new int[n];

        for (int i = 0; i < n; i++) {
            arr[i] = list.get(i);
        }

        System.out.println("Random Numbers (Without Duplicates)");
        System.out.println("Original Array:");
        System.out.println(Arrays.toString(arr));

        long start = System.nanoTime();
        selectionSort(arr);
        long end = System.nanoTime();

        System.out.println("\nSorted Array:");
        System.out.println(Arrays.toString(arr));
        System.out.println("Execution Time: " + (end - start) + " ns");



        // Ascending Order 
        arr = new int[n];

        for (int i = 0; i < n; i++) {
            arr[i] = i + 1;
        }

        System.out.println("\n\nAscending Order");
        System.out.println("Original Array:");
        System.out.println(Arrays.toString(arr));

        start = System.nanoTime();
        selectionSort(arr);
        end = System.nanoTime();

        System.out.println("Sorted Array:");
        System.out.println(Arrays.toString(arr));
        System.out.println("Execution Time: " + (end - start) + " ns");



        // Descending Order 
        arr = new int[n];

        for (int i = 0; i < n; i++) {
            arr[i] = n - i;
        }

        System.out.println("\n\nDescending Order");
        System.out.println("Original Array:");
        System.out.println(Arrays.toString(arr));

        start = System.nanoTime();
        selectionSort(arr);
        end = System.nanoTime();

        System.out.println("Sorted Array:");
        System.out.println(Arrays.toString(arr));
        System.out.println("Execution Time: " + (end - start) + " ns");



        //  Missing Numbers 
        list.clear();

        for (int i = 1; i <= 100; i++) {
            list.add(i);
        }

        Collections.shuffle(list);

        ArrayList<Integer> missing = new ArrayList<>();

        
        for (int i = 0; i < 10; i++) {
            missing.add(list.remove(0));
        }

        Collections.sort(missing);

        arr = new int[list.size()];

        for (int i = 0; i < list.size(); i++) {
            arr[i] = list.get(i);
        }

        System.out.println("\n\nMissing Numbers");
        System.out.println("Missing Values:");
        System.out.println(missing);

        System.out.println("Original Array:");
        System.out.println(Arrays.toString(arr));

        start = System.nanoTime();
        selectionSort(arr);
        end = System.nanoTime();

        System.out.println("Sorted Array:");
        System.out.println(Arrays.toString(arr));
        System.out.println("Execution Time: " + (end - start) + " ns");



        //  Duplicate Numbers
        arr = new int[n];

        for (int i = 0; i < n; i++) {
            arr[i] = random.nextInt(100) + 1;
        }

        System.out.println("\n\nDuplicate Numbers");
        System.out.println("Original Array:");
        System.out.println(Arrays.toString(arr));

        start = System.nanoTime();
        selectionSort(arr);
        end = System.nanoTime();

        System.out.println("Sorted Array:");
        System.out.println(Arrays.toString(arr));
        System.out.println("Execution Time: " + (end - start) + " ns");



        // Partially Ordered 
        arr = new int[n];

        for (int i = 0; i < 50; i++) {
            arr[i] = i + 1;
        }

       
        for (int i = 50; i < n; i++) {
            arr[i] = random.nextInt(100) + 1;
        }

        System.out.println("\n\nPartially Ordered");
        System.out.println("Original Array:");
        System.out.println(Arrays.toString(arr));

        start = System.nanoTime();
        selectionSort(arr);
        end = System.nanoTime();

        System.out.println("Sorted Array:");
        System.out.println(Arrays.toString(arr));
        System.out.println("Execution Time: " + (end - start) + " ns");
    }
}