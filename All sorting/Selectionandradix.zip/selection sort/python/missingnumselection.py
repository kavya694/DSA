import random
import time
def selection_sort(arr):
    n = len(arr)
    for i in range(n - 1):
        min = i
        for j in range(i + 1, n):
            if arr[j] < arr[min]:
                min = j
        arr[i], arr[min] = arr[min], arr[i]

arr = list(range(1, 100))


missing = random.sample(arr, 12)

for num in missing:
    arr.remove(num)

print("Missing Numbers:")
print(sorted(missing))

print("\nOriginal Array of missing numbers:")
print(arr)
start = time.perf_counter()
selection_sort(arr)
end = time.perf_counter()
print("\nSorted Array 0f missing number:")
print(arr)
print("\nExecution Time:", end - start, "seconds")
#duplicates
n=100
arrdup=[random.randint(1,100) for _ in range(n)]
print("original array of dulicates")
print(arrdup)
start = time.perf_counter()
selection_sort(arrdup)
end = time.perf_counter()
print("\n Sorted Array of duplicates:")
print(arrdup)
print("\nExecution Time:", end - start, "seconds")