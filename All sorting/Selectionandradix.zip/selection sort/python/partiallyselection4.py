import random
import time

# Selection Sort
def selection_sort(arr):
    n = len(arr)

    for i in range(n - 1):
        min = i

        for j in range(i + 1, n):
            if arr[j] < arr[min]:
                min = j

        arr[i], arr[min] = arr[min], arr[i]


n = 100000

arr = []


for i in range(1, 50001):
    arr.append(i)


for i in range(50000):
    arr.append(random.randint(1, 100000))

print("original array:")
print(arr)

start = time.perf_counter()

selection_sort(arr)

end = time.perf_counter()

print("\nsorting array:")
print(arr)

print("\nExecution Time:", end - start, "seconds")