import random
import time
def selection_sort(arr):
    n = len(arr)
    for i in range(n - 1):
        min = i
        for j in range(i + 1, n):
            if arr[j] < arr[min]:
                min = j
        arr[i], arr[min] = arr[min], arr[i]


#random num
n = 1000
arr = random.sample(range(1, 1001), 1000)

print("Random Numbers (Without Duplicates)")
print("Original Array:")
print(arr)

start = time.perf_counter()
selection_sort(arr)

end = time.perf_counter()

print("\nSorted Array:")
print(arr)

print(f"\nExecution Time: {end - start:.5f} seconds")

#ASCENDING
arr = list(range(1, n + 1))

print("\nAscending Order")

print("Original Array of ascenging order:")
print(arr)
start = time.perf_counter()
selection_sort(arr)
end = time.perf_counter()
print("Sorted Array:")
print(arr)
print(f"\nExecution Time: {end - start:.5f} seconds")

# Descending Order 
arr = list(range(n, 0, -1))

print("\nDescending Order")
print("Original Array:")
print(arr)
start = time.perf_counter()
selection_sort(arr)
end = time.perf_counter()
print("Sorted Array:")
print(arr)
print(f"\nExecution Time: {end - start:.5f} seconds")

#  Missing Numbers 
arr = list(range(1, 1001))

missing = random.sample(arr, 100)

for num in missing:
    arr.remove(num)

print("\nMissing Numbers")
print("Missing Values:")
print(sorted(missing))

print("Original Array :")
print(arr)
start = time.perf_counter()
selection_sort(arr)
end = time.perf_counter()
print("Sorted Array:")
print(arr)
print(f"\nExecution Time: {end - start:.5f} seconds")

#  Duplicate Numbers 
arr = [random.randint(1, 1000) for _ in range(n)]

print("\nDuplicate Numbers")
print("Original Array:")
print(arr)
start = time.perf_counter()
selection_sort(arr)
end = time.perf_counter()
print("Sorted Array:")
print(arr)
print(f"\nExecution Time: {end - start:.5f} seconds")
#partially
arr = []
for i in range(500):
    arr.append(i + 1)
for i in range(500):
    arr.append(random.randint(1, 1000))

print("Input Array:")
print(arr)

start = time.perf_counter()

selection_sort(arr)

end = time.perf_counter()

print("\nSorted Array (Ascending):")
print(arr)

print("\nExecution Time:", end - start, "seconds")