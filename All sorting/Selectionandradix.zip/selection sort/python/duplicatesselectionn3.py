import random
import time
def selection_sort(arr):
    n = len(arr)
    for i in range(n - 1):
        min = i
        for j in range(i + 1, n):
            if arr[j] < arr[min]:
                min = j
        arr[i], arr[min] = arr[min], arr[i]
n=10000
#  Duplicate Numbers 
arr = [random.randint(1, 10000) for _ in range(n)]

print("\nDuplicate Numbers")
print("Original Array:")
print(arr)
start = time.perf_counter()
selection_sort(arr)
end = time.perf_counter()
print("Sorted Array:")
print(arr)
print(f"\nExecution Time: {end - start:.5f} seconds")

