import random
import time


def selection_sort(arr):
    n = len(arr)
    for i in range(n - 1):
        min = i
        for j in range(i + 1, n):
            if arr[j] < arr[min]:
                min = j
        arr[i], arr[min] = arr[min], arr[i]

arr = []
for i in range(50):
    arr.append(i + 1)
for i in range(50):
    arr.append(random.randint(1, 100))

print("Input Array:")
print(arr)

start = time.perf_counter()

selection_sort(arr)

end = time.perf_counter()

print("\nSorted Array (Ascending):")
print(arr)

print("\nExecution Time:", end - start, "seconds")