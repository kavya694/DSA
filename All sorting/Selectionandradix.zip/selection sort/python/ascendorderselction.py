import time
def selection_sort(arr):
    n=len(arr)
    for i in range(n-1):
        min=i
        for j in range(i+1,n):
            if arr[j]<arr[min]:
                min=j
        arr[i],arr[min]=arr[min],arr[i]

n=100
arr=list(range(1,n+1))
print("original Array")
print(arr)
start = time.perf_counter()
selection_sort(arr)

end = time.perf_counter()

print("\nSorted Array:")
print(arr)

print(f"\nExecution Time: {end - start:.5f} seconds")