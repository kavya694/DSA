import random
import time
def selection_sort(arr):
    n = len(arr)
    for i in range(n - 1):
        min = i
        for j in range(i + 1, n):
            if arr[j] < arr[min]:
                min = j
        arr[i], arr[min] = arr[min], arr[i]

n=100000
# Descending Order 
arr = list(range(n, 0, -1))

print("\nDescending Order")
print("Original Array:")
print(arr)
start = time.perf_counter()
selection_sort(arr)
end = time.perf_counter()
print("Sorted Array:")
print(arr)
print(f"\nExecution Time: {end - start:.5f} seconds")