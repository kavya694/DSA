
import java.util.*;

public class RadixSortCases {

    // Counting Sort used by Radix Sort
    static void countingSort(int[] arr, int exp) {
        int n = arr.length;
        int[] output = new int[n];
        int[] count = new int[10];

        // Count occurrences
        for (int i = 0; i < n; i++) {
            count[(arr[i] / exp) % 10]++;
        }

        // Cumulative count
        for (int i = 1; i < 10; i++) {
            count[i] += count[i - 1];
        }

        // Build output array
        for (int i = n - 1; i >= 0; i--) {
            output[count[(arr[i] / exp) % 10] - 1] = arr[i];
            count[(arr[i] / exp) % 10]--;
        }

        // Copy output to original array
        for (int i = 0; i < n; i++) {
            arr[i] = output[i];
        }
    }

    // Radix Sort
    static void radixSort(int[] arr) {
        if (arr.length == 0)
            return;

        int max = arr[0];

        for (int x : arr) {
            if (x > max)
                max = x;
        }

        for (int exp = 1; max / exp > 0; exp *= 10) {
            countingSort(arr, exp);
        }
    }

    public static void main(String[] args) {

        int n = 100000; // Size = 100000
        Random rand = new Random();

        int[] arr;
        ArrayList<Integer> list = new ArrayList<>();
        ArrayList<Integer> missing = new ArrayList<>();

        // ================= Random Numbers (Without Duplicates) =================
        list.clear();
        for (int i = 1; i <= n; i++)
            list.add(i);

        Collections.shuffle(list);

        arr = new int[n];
        for (int i = 0; i < n; i++)
            arr[i] = list.get(i);

        System.out.println("======================================");
        System.out.println("Random Numbers (Without Duplicates)");
        System.out.println("======================================");

        long start = System.nanoTime();
        radixSort(arr);
        long end = System.nanoTime();

        System.out.println("Execution Time: " + (end - start) + " ns");

        // ================= Ascending Order =================
        arr = new int[n];

        for (int i = 0; i < n; i++)
            arr[i] = i + 1;

        System.out.println("\n======================================");
        System.out.println("Ascending Order");
        System.out.println("======================================");

        start = System.nanoTime();
        radixSort(arr);
        end = System.nanoTime();

        System.out.println("Execution Time: " + (end - start) + " ns");

        // ================= Descending Order =================
        arr = new int[n];

        for (int i = 0; i < n; i++)
            arr[i] = n - i;

        System.out.println("\n======================================");
        System.out.println("Descending Order");
        System.out.println("======================================");

        start = System.nanoTime();
        radixSort(arr);
        end = System.nanoTime();

        System.out.println("Execution Time: " + (end - start) + " ns");

        // ================= Missing Numbers =================
        list.clear();
        for (int i = 1; i <= n; i++)
            list.add(i);

        Collections.shuffle(list);

        missing.clear();

        // Remove 10000 numbers
        for (int i = 0; i < 10000; i++) {
            missing.add(list.remove(0));
        }

        Collections.sort(missing);

        arr = new int[list.size()];
        for (int i = 0; i < list.size(); i++)
            arr[i] = list.get(i);

        System.out.println("\n======================================");
        System.out.println("Missing Numbers");
        System.out.println("======================================");
        System.out.println("Missing Numbers Count: " + missing.size());

        start = System.nanoTime();
        radixSort(arr);
        end = System.nanoTime();

        System.out.println("Execution Time: " + (end - start) + " ns");

        // ================= Duplicate Numbers =================
        arr = new int[n];

        for (int i = 0; i < n; i++)
            arr[i] = rand.nextInt(100000) + 1;

        System.out.println("\n======================================");
        System.out.println("Duplicate Numbers");
        System.out.println("======================================");

        start = System.nanoTime();
        radixSort(arr);
        end = System.nanoTime();

        System.out.println("Execution Time: " + (end - start) + " ns");

        // ================= Partially Ordered =================
        arr = new int[n];

        // First half sorted
        for (int i = 0; i < n / 2; i++)
            arr[i] = i + 1;

        // Second half random
        for (int i = n / 2; i < n; i++)
            arr[i] = rand.nextInt(100000) + 1;

        System.out.println("\n======================================");
        System.out.println("Partially Ordered");
        System.out.println("======================================");

        start = System.nanoTime();
        radixSort(arr);
        end = System.nanoTime();

        System.out.println("Execution Time: " + (end - start) + " ns");
    }
}