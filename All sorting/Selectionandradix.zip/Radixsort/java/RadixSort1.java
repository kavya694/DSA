import java.util.*;

public class RadixSort1 {


    static void countingSort(int[] arr, int exp) {
        int n = arr.length;
        int[] output = new int[n];
        int[] count = new int[10];
        for (int i = 0; i < n; i++) {
            count[(arr[i] / exp) % 10]++;
        }
        for (int i = 1; i < 10; i++) {
            count[i] += count[i - 1];
        }
        for (int i = n - 1; i >= 0; i--) {
            output[count[(arr[i] / exp) % 10] - 1] = arr[i];
            count[(arr[i] / exp) % 10]--;
        }
        for (int i = 0; i < n; i++) {
            arr[i] = output[i];
        }
    }
    static void radixSort(int[] arr) {
        int max = arr[0];

        for (int x : arr) {
            if (x > max)
                max = x;
        }

        for (int exp = 1; max / exp > 0; exp *= 10) {
            countingSort(arr, exp);
        }
    }

    static void printArray(int[] arr) {
        for (int x : arr)
            System.out.print(x + " ");
        System.out.println();
    }

    public static void main(String[] args) {

        int n = 100;
        Random rand = new Random();

        int[] arr;
        ArrayList<Integer> list = new ArrayList<>();
        ArrayList<Integer> missing = new ArrayList<>();

        //  Random Numbers 
        list.clear();
        for (int i = 1; i <= n; i++)
            list.add(i);

        Collections.shuffle(list);

        arr = new int[n];
        for (int i = 0; i < n; i++)
            arr[i] = list.get(i);

        System.out.println("Random Numbers (Without Duplicates)");
        System.out.println("Original Array:");
        printArray(arr);

        long start = System.nanoTime();
        radixSort(arr);
        long end = System.nanoTime();

        System.out.println("\nSorted Array:");
        printArray(arr);
        System.out.println("Execution Time: " + (end - start) + " ns");


        //  Ascending Order 
        arr = new int[n];

        for (int i = 0; i < n; i++)
            arr[i] = i + 1;

        System.out.println("\nAscending Order");
        System.out.println("Original Array:");
        printArray(arr);

        start = System.nanoTime();
        radixSort(arr);
        end = System.nanoTime();

        System.out.println("\nSorted Array:");
        printArray(arr);
        System.out.println("Execution Time: " + (end - start) + " ns");


        //  Descending Order 
        arr = new int[n];

        for (int i = 0; i < n; i++)
            arr[i] = n - i;

        System.out.println("\nDescending Order");
        System.out.println("Original Array:");
        printArray(arr);

        start = System.nanoTime();
        radixSort(arr);
        end = System.nanoTime();

        System.out.println("\nSorted Array:");
        printArray(arr);
        System.out.println("Execution Time: " + (end - start) + " ns");


        //  Missing Numbers 
        list.clear();
        for (int i = 1; i <= n; i++)
            list.add(i);

        Collections.shuffle(list);

        missing.clear();

        for (int i = 0; i < 10; i++) {
            missing.add(list.remove(0));
        }

        Collections.sort(missing);

        arr = new int[list.size()];
        for (int i = 0; i < list.size(); i++)
            arr[i] = list.get(i);

        System.out.println("\nMissing Numbers");
        System.out.println("Missing Values:");
        for (int x : missing)
            System.out.print(x + " ");

        System.out.println("\nOriginal Array:");
        printArray(arr);

        start = System.nanoTime();
        radixSort(arr);
        end = System.nanoTime();

        System.out.println("\nSorted Array:");
        printArray(arr);
        System.out.println("Execution Time: " + (end - start) + " ns");


        // = Duplicate Numbers 
        arr = new int[n];

        for (int i = 0; i < n; i++)
            arr[i] = rand.nextInt(100) + 1;

        System.out.println("\nDuplicate Numbers");
        System.out.println("Original Array:");
        printArray(arr);

        start = System.nanoTime();
        radixSort(arr);
        end = System.nanoTime();

        System.out.println("\nSorted Array:");
        printArray(arr);
        System.out.println("Execution Time: " + (end - start) + " ns");


        //  Partially Ordered 
        arr = new int[n];

        for (int i = 0; i < 50; i++)
            arr[i] = i + 1;

        for (int i = 50; i < n; i++)
            arr[i] = rand.nextInt(100) + 1;

        System.out.println("\nPartially Ordered");
        System.out.println("Original Array:");
        printArray(arr);

        start = System.nanoTime();
        radixSort(arr);
        end = System.nanoTime();

        System.out.println("\nSorted Array:");
        printArray(arr);
        System.out.println("Execution Time: " + (end - start) + " ns");
    }
}