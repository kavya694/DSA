import random
import time

# ---------------- Radix Sort ----------------
def counting_sort(arr, exp):
    n = len(arr)
    output = [0] * n
    count = [0] * 10

    # Count occurrences
    for num in arr:
        index = (num // exp) % 10
        count[index] += 1

    # Cumulative count
    for i in range(1, 10):
        count[i] += count[i - 1]

    # Build output array
    for i in range(n - 1, -1, -1):
        index = (arr[i] // exp) % 10
        output[count[index] - 1] = arr[i]
        count[index] -= 1

    # Copy output to original array
    for i in range(n):
        arr[i] = output[i]


def radix_sort(arr):
    if len(arr) == 0:
        return

    maximum = max(arr)
    exp = 1

    while maximum // exp > 0:
        counting_sort(arr, exp)
        exp *= 10


# ================= Main Program =================

n = 10000

# ================= Random Numbers (Without Duplicates) =================
arr = list(range(1, n + 1))
random.shuffle(arr)

print("=" * 60)
print("Random Numbers (Without Duplicates)")
print("=" * 60)
print("Original Array:")
print(arr)

start = time.perf_counter_ns()
radix_sort(arr)
end = time.perf_counter_ns()

print("\nSorted Array:")
print(arr)
print("Execution Time:", end - start, "ns")


# ================= Ascending Order =================
arr = list(range(1, n + 1))

print("\n" + "=" * 60)
print("Ascending Order")
print("=" * 60)
print("Original Array:")
print(arr)

start = time.perf_counter_ns()
radix_sort(arr)
end = time.perf_counter_ns()

print("\nSorted Array:")
print(arr)
print("Execution Time:", end - start, "ns")


# ================= Descending Order =================
arr = list(range(n, 0, -1))

print("\n" + "=" * 60)
print("Descending Order")
print("=" * 60)
print("Original Array:")
print(arr)

start = time.perf_counter_ns()
radix_sort(arr)
end = time.perf_counter_ns()

print("\nSorted Array:")
print(arr)
print("Execution Time:", end - start, "ns")


# ================= Missing Numbers =================
numbers = list(range(1, n + 1))
random.shuffle(numbers)

missing = sorted(numbers[:10])      # Remove 10 numbers
arr = numbers[10:]

print("\n" + "=" * 60)
print("Missing Numbers")
print("=" * 60)
print("Missing Values:")
print(missing)

print("\nOriginal Array:")
print(arr)

start = time.perf_counter_ns()
radix_sort(arr)
end = time.perf_counter_ns()

print("\nSorted Array:")
print(arr)
print("Execution Time:", end - start, "ns")


# ================= Duplicate Numbers =================
arr = [random.randint(1, n) for _ in range(n)]

print("\n" + "=" * 60)
print("Duplicate Numbers")
print("=" * 60)
print("Original Array:")
print(arr)

start = time.perf_counter_ns()
radix_sort(arr)
end = time.perf_counter_ns()

print("\nSorted Array:")
print(arr)
print("Execution Time:", end - start, "ns")


# ================= Partially Ordered =================
arr = list(range(1, n // 2 + 1))

for _ in range(n // 2):
    arr.append(random.randint(1, n))

print("\n" + "=" * 60)
print("Partially Ordered")
print("=" * 60)
print("Original Array:")
print(arr)

start = time.perf_counter_ns()
radix_sort(arr)
end = time.perf_counter_ns()

print("\nSorted Array:")
print(arr)
print("Execution Time:", end - start, "ns")