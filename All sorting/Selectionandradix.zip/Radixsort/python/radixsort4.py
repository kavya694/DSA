import random
import time

def counting_sort(arr, exp):
    n = len(arr)
    output=[0]*n
    count=[0]*10
    for num in arr:
        count[(num//exp)%10]+=1
    for i in range(1,10):
        count[i]+=count[i-1]
    for i in range(n-1,-1,-1):
        idx=(arr[i]//exp)%10
        output[count[idx]-1]=arr[i]
        count[idx]-=1
    arr[:] = output

def radix_sort(arr):
    if not arr: return
    m=max(arr); exp=1
    while m//exp>0:
        counting_sort(arr,exp)
        exp*=10

def run_case(title, arr, missing=None):
    print("="*60)
    print(title)
    print("="*60)
    if missing is not None:
        print("Missing Values:", missing)
    print("Original Array (first 20):", arr[:20])
    print("Original Array (last 20):", arr[-20:])
    s=time.perf_counter_ns()
    radix_sort(arr)
    e=time.perf_counter_ns()
    print("Sorted Array (first 20):", arr[:20])
    print("Sorted Array (last 20):", arr[-20:])
    print("Execution Time:", e-s, "ns\n")

n=100000

arr=list(range(1,n+1)); random.shuffle(arr)
run_case("Random Numbers (Without Duplicates)", arr)

arr=list(range(1,n+1))
run_case("Ascending Order", arr)

arr=list(range(n,0,-1))
run_case("Descending Order", arr)

nums=list(range(1,n+1)); random.shuffle(nums)
missing=sorted(nums[:10]); arr=nums[10:]
run_case("Missing Numbers", arr, missing)

arr=[random.randint(1,n) for _ in range(n)]
run_case("Duplicate Numbers", arr)

arr=list(range(1,n//2+1))
arr.extend(random.randint(1,n) for _ in range(n//2))
run_case("Partially Ordered", arr)
