import random
import time


def counting_sort(arr, exp):
    n = len(arr)
    output = [0] * n
    count = [0] * 10

    
    for num in arr:
        index = (num // exp) % 10
        count[index] += 1

    
    for i in range(1, 10):
        count[i] += count[i - 1]

    
    for i in range(n - 1, -1, -1):
        index = (arr[i] // exp) % 10
        output[count[index] - 1] = arr[i]
        count[index] -= 1

    
    for i in range(n):
        arr[i] = output[i]


def radix_sort(arr):
    if len(arr) == 0:
        return

    maximum = max(arr)
    exp = 1

    while maximum // exp > 0:
        counting_sort(arr, exp)
        exp *= 10



n = 100

#  Random Numbers (Without Duplicates) 
arr = list(range(1, 101))
random.shuffle(arr)

print("Random Numbers (Without Duplicates)")
print("Original Array:")
print(arr)

start = time.perf_counter_ns()
radix_sort(arr)
end = time.perf_counter_ns()

print("\nSorted Array:")
print(arr)
print("Execution Time:", end - start, "ns")


# Ascending Order 
arr = list(range(1, n + 1))

print("\n\nAscending Order")
print("Original Array:")
print(arr)

start = time.perf_counter_ns()
radix_sort(arr)
end = time.perf_counter_ns()

print("\nSorted Array:")
print(arr)
print("Execution Time:", end - start, "ns")


#  Descending Order 
arr = list(range(n, 0, -1))

print("\n\nDescending Order")
print("Original Array:")
print(arr)

start = time.perf_counter_ns()
radix_sort(arr)
end = time.perf_counter_ns()

print("\nSorted Array:")
print(arr)
print("Execution Time:", end - start, "ns")


#  Missing Numbers 
numbers = list(range(1, 101))
random.shuffle(numbers)

missing = sorted(numbers[:10])
arr = numbers[10:]

print("\n\nMissing Numbers")
print("Missing Values:")
print(missing)

print("Original Array:")
print(arr)

start = time.perf_counter_ns()
radix_sort(arr)
end = time.perf_counter_ns()

print("\nSorted Array:")
print(arr)
print("Execution Time:", end - start, "ns")


#  Duplicate Numbers 
arr = [random.randint(1, 100) for _ in range(n)]

print("\n\nDuplicate Numbers")
print("Original Array:")
print(arr)

start = time.perf_counter_ns()
radix_sort(arr)
end = time.perf_counter_ns()

print("\nSorted Array:")
print(arr)
print("Execution Time:", end - start, "ns")


#  Partially Ordered
arr = list(range(1, 51))

for _ in range(50):
    arr.append(random.randint(1, 100))

print("\n\nPartially Ordered")
print("Original Array:")
print(arr)

start = time.perf_counter_ns()
radix_sort(arr)
end = time.perf_counter_ns()

print("\nSorted Array:")
print(arr)
print("Execution Time:", end - start, "ns")