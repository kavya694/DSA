
#include <iostream>
#include <vector>
#include <algorithm>
#include <random>
#include <chrono>

using namespace std;

// Counting Sort for Radix Sort
void countingSort(vector<int>& arr, int exp) {
    int n = arr.size();
    vector<int> output(n);
    int count[10] = {0};

    // Count occurrences
    for (int i = 0; i < n; i++)
        count[(arr[i] / exp) % 10]++;

    // Cumulative count
    for (int i = 1; i < 10; i++)
        count[i] += count[i - 1];

    // Build output array
    for (int i = n - 1; i >= 0; i--) {
        output[count[(arr[i] / exp) % 10] - 1] = arr[i];
        count[(arr[i] / exp) % 10]--;
    }

    // Copy output
    for (int i = 0; i < n; i++)
        arr[i] = output[i];
}

// Radix Sort
void radixSort(vector<int>& arr) {
    int maxVal = *max_element(arr.begin(), arr.end());

    for (int exp = 1; maxVal / exp > 0; exp *= 10)
        countingSort(arr, exp);
}

// Print Array
void printArray(const vector<int>& arr) {
    for (int x : arr)
        cout << x << " ";
    cout << endl;
}

int main() {

    int n = 1000;
    random_device rd;
    mt19937 gen(rd());

    vector<int> arr;
    vector<int> list;
    vector<int> missing;

    // ================= Random Numbers (Without Duplicates) =================
    list.clear();
    for (int i = 1; i <= n; i++)
        list.push_back(i);

    shuffle(list.begin(), list.end(), gen);

    arr = list;

    cout << "======================================" << endl;
    cout << "Random Numbers (Without Duplicates)" << endl;
    cout << "======================================" << endl;
    cout << "Original Array:" << endl;
    printArray(arr);

    auto start = chrono::high_resolution_clock::now();
    radixSort(arr);
    auto end = chrono::high_resolution_clock::now();

    cout << "\nSorted Array:" << endl;
    printArray(arr);

    cout << "Execution Time: "
         << chrono::duration_cast<chrono::nanoseconds>(end - start).count()
         << " ns" << endl;

    // ================= Ascending Order =================
    arr.clear();
    for (int i = 1; i <= n; i++)
        arr.push_back(i);

    cout << "\n======================================" << endl;
    cout << "Ascending Order" << endl;
    cout << "======================================" << endl;
    cout << "Original Array:" << endl;
    printArray(arr);

    start = chrono::high_resolution_clock::now();
    radixSort(arr);
    end = chrono::high_resolution_clock::now();

    cout << "\nSorted Array:" << endl;
    printArray(arr);

    cout << "Execution Time: "
         << chrono::duration_cast<chrono::nanoseconds>(end - start).count()
         << " ns" << endl;

    // ================= Descending Order =================
    arr.clear();
    for (int i = n; i >= 1; i--)
        arr.push_back(i);

    cout << "\n======================================" << endl;
    cout << "Descending Order" << endl;
    cout << "======================================" << endl;
    cout << "Original Array:" << endl;
    printArray(arr);

    start = chrono::high_resolution_clock::now();
    radixSort(arr);
    end = chrono::high_resolution_clock::now();

    cout << "\nSorted Array:" << endl;
    printArray(arr);

    cout << "Execution Time: "
         << chrono::duration_cast<chrono::nanoseconds>(end - start).count()
         << " ns" << endl;

    // ================= Missing Numbers =================
    list.clear();
    for (int i = 1; i <= n; i++)
        list.push_back(i);

    shuffle(list.begin(), list.end(), gen);

    missing.clear();

    // Remove 100 numbers
    for (int i = 0; i < 100; i++) {
        missing.push_back(list.front());
        list.erase(list.begin());
    }

    sort(missing.begin(), missing.end());

    arr = list;

    cout << "\n======================================" << endl;
    cout << "Missing Numbers" << endl;
    cout << "======================================" << endl;

    cout << "Missing Values:" << endl;
    for (int x : missing)
        cout << x << " ";

    cout << "\n\nOriginal Array:" << endl;
    printArray(arr);

    start = chrono::high_resolution_clock::now();
    radixSort(arr);
    end = chrono::high_resolution_clock::now();

    cout << "\nSorted Array:" << endl;
    printArray(arr);

    cout << "Execution Time: "
         << chrono::duration_cast<chrono::nanoseconds>(end - start).count()
         << " ns" << endl;

    // ================= Duplicate Numbers =================
    arr.clear();
    uniform_int_distribution<> dist(1, 1000);

    for (int i = 0; i < n; i++)
        arr.push_back(dist(gen));

    cout << "\n======================================" << endl;
    cout << "Duplicate Numbers" << endl;
    cout << "======================================" << endl;
    cout << "Original Array:" << endl;
    printArray(arr);

    start = chrono::high_resolution_clock::now();
    radixSort(arr);
    end = chrono::high_resolution_clock::now();

    cout << "\nSorted Array:" << endl;
    printArray(arr);

    cout << "Execution Time: "
         << chrono::duration_cast<chrono::nanoseconds>(end - start).count()
         << " ns" << endl;

    // ================= Partially Ordered =================
    arr.clear();

    // First half sorted
    for (int i = 1; i <= n / 2; i++)
        arr.push_back(i);

    // Second half random
    for (int i = n / 2; i < n; i++)
        arr.push_back(dist(gen));

    cout << "\n======================================" << endl;
    cout << "Partially Ordered" << endl;
    cout << "======================================" << endl;
    cout << "Original Array:" << endl;
    printArray(arr);

    start = chrono::high_resolution_clock::now();
    radixSort(arr);
    end = chrono::high_resolution_clock::now();

    cout << "\nSorted Array:" << endl;
    printArray(arr);

    cout << "Execution Time: "
         << chrono::duration_cast<chrono::nanoseconds>(end - start).count()
         << " ns" << endl;

    return 0;
}

